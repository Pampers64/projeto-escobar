<!-- resources/views/template/principal/monitoramento.blade.php -->
@extends('tamplate.layout.index')

@section('monitoramento')
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="text-center mb-4">Painel de Monitoramento</h1>

            <div class="row">
                <!-- Status do Sistema -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <h2 class="card-title">Status do Sistema</h2>
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="text-success">Operacional</h3>
                                    <p>Todos os sistemas estão funcionando normalmente.</p>
                                </div>
                                <div>
                                    <i class="fas fa-server fa-3x text-success"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Desempenho do Sistema -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <h2 class="card-title">Desempenho</h2>
                            <div>
                                <canvas id="performanceChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Uso de Recursos -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <h2 class="card-title">Uso de Recursos</h2>
                            <div class="progress mb-2">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">CPU: 70%</div>
                            </div>
                            <div class="progress mb-2">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">Memória: 50%</div>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 30%;" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100">Disco: 30%</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Logs Recentes -->
            <div class="row mt-5">
                <div class="col-12">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <h2 class="card-title">Logs Recentes</h2>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
                                            <th>Tipo</th>
                                            <th>Mensagem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>2024-09-13 10:00</td>
                                            <td><span class="badge badge-success">INFO</span></td>
                                            <td>Serviço iniciado com sucesso.</td>
                                        </tr>
                                        <tr>
                                            <td>2024-09-13 10:15</td>
                                            <td><span class="badge badge-warning">WARNING</span></td>
                                            <td>Uso elevado de CPU detectado.</td>
                                        </tr>
                                        <tr>
                                            <td>2024-09-13 10:30</td>
                                            <td><span class="badge badge-danger">ERROR</span></td>
                                            <td>Falha ao conectar ao banco de dados.</td>
                                        </tr>
                                        <!-- Adicione mais linhas conforme necessário -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var ctx = document.getElementById('performanceChart').getContext('2d');
    var performanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            datasets: [{
                label: 'Desempenho',
                data: [12, 19, 3, 5, 2, 3, 7],
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
@stop
