<!-- resources/views/template/principal/produto.blade.php -->
@extends('tamplate.layout.index')

@section('produto')
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-10 offset-lg-1">
            <h1 class="text-center mb-4">Nossos Pacotes de Sites</h1>

            <div class="row">
                <!-- Pacote Básico -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4 text-center">
                            <h2 class="card-title">Pacote Básico</h2>
                            <h3 class="card-price">$499</h3>
                            <p class="card-text">Ideal para pequenas empresas ou blogs pessoais. Inclui:</p>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check-circle text-success"></i> Design Personalizado</li>
                                <li><i class="fas fa-check-circle text-success"></i> Até 5 Páginas</li>
                                <li><i class="fas fa-check-circle text-success"></i> Responsivo</li>
                                <li><i class="fas fa-check-circle text-success"></i> Formulário de Contato</li>
                            </ul>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>

                <!-- Pacote Profissional -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4 text-center">
                            <h2 class="card-title">Pacote Profissional</h2>
                            <h3 class="card-price">$799</h3>
                            <p class="card-text">Perfeito para empresas em crescimento e e-commerces. Inclui:</p>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check-circle text-success"></i> Design Personalizado</li>
                                <li><i class="fas fa-check-circle text-success"></i> Até 10 Páginas</li>
                                <li><i class="fas fa-check-circle text-success"></i> Responsivo</li>
                                <li><i class="fas fa-check-circle text-success"></i> E-commerce Integrado</li>
                                <li><i class="fas fa-check-circle text-success"></i> SEO Básico</li>
                            </ul>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>

                <!-- Pacote Premium -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4 text-center">
                            <h2 class="card-title">Pacote Premium</h2>
                            <h3 class="card-price">$1199</h3>
                            <p class="card-text">Para grandes empresas e projetos complexos. Inclui:</p>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check-circle text-success"></i> Design Personalizado</li>
                                <li><i class="fas fa-check-circle text-success"></i> Páginas Ilimitadas</li>
                                <li><i class="fas fa-check-circle text-success"></i> Responsivo</li>
                                <li><i class="fas fa-check-circle text-success"></i> E-commerce Avançado</li>
                                <li><i class="fas fa-check-circle text-success"></i> SEO Avançado</li>
                                <li><i class="fas fa-check-circle text-success"></i> Suporte Premium</li>
                            </ul>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Seção de Testemunhos (opcional) -->
            <div class="row mt-5">
                <div class="col-12">
                    <h2 class="text-center mb-4">O que nossos clientes dizem</h2>
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <blockquote class="blockquote text-center">
                                <p class="mb-0">"O serviço da ADM foi excelente. O site que criaram para nós superou todas as expectativas. Recomendo a todos!"</p>
                                <footer class="blockquote-footer">Maria Oliveira, <cite title="Source Title">Empresária</cite></footer>
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop
