<!-- resources/views/template/principal/contato.blade.php -->
@extends('tamplate.layout.index')

@section('contato')
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-10 offset-lg-1">
            <h1 class="text-center mb-4">Contato</h1>
            
            <div class="row">
                <!-- Formulário de Contato -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <h2 class="card-title">Envie-nos uma Mensagem</h2>
                            <form>
                                <div class="form-group">
                                    <label for="name">Nome</label>
                                    <input type="text" class="form-control" id="name" placeholder="Seu nome" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="Seu email" required>
                                </div>
                                <div class="form-group">
                                    <label for="message">Mensagem</label>
                                    <textarea class="form-control" id="message" rows="4" placeholder="Sua mensagem" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Enviar</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <!-- Informações de Contato -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <h2 class="card-title">Informações de Contato</h2>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-map-marker-alt text-primary"></i> Rua Exemplo, 123, São Paulo, SP, Brasil</li>
                                <li><i class="fas fa-phone-alt text-primary"></i> +55 11 1234-5678</li>
                                <li><i class="fas fa-envelope text-primary"></i> contato@adm.com.br</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Mapa (Opcional) -->
            <div class="row">
                <div class="col-12">
                    <h2 class="text-center mb-4">Nosso Local</h2>
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <div class="embed-responsive embed-responsive-16by9">
                                <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14643.1846699757!2d-46.64709118611127!3d-23.556553287741227!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce6a334b2b9e5b%3A0x2687db0b59a9241f!2sRua%20Exemplo%2C%20123%20-%20Jardim%20Paulistano%2C%20São%20Paulo%20-%20SP%2C%2012345-678%2C%20Brasil!5e0!3m2!1spt-BR!2sbr!4v1631622451582!5m2!1spt-BR!2sbr" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop
