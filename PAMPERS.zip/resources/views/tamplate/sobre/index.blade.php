<!-- resources/views/template/principal/sobre.blade.php -->
@extends("tamplate.layout.index")

@section('sobre')
<div class="container mt-5">
    <div class="row">
        <div class="col-lg-10 offset-lg-1">
            <h1 class="text-center mb-4">Sobre a ADM</h1>
            <div class="card shadow-lg border-0 rounded mb-4">
                <div class="card-body p-4">
                    <h2 class="card-title">Quem Somos</h2>
                    <p class="card-text">A ADM é uma empresa líder no setor de tecnologia, dedicada a fornecer soluções inovadoras para otimizar processos empresariais e melhorar a eficiência organizacional. Fundada em 2024, a ADM tem se destacado pela excelência em seus serviços e pela capacidade de se adaptar às necessidades dos nossos clientes.</p>
                    
                    <h2 class="card-title">Nossa Missão</h2>
                    <p class="card-text">Com anos de experiência e uma equipe altamente qualificada, a ADM oferece uma ampla gama de serviços, incluindo desenvolvimento de software, consultoria em TI e suporte técnico. Nosso objetivo é ajudar nossos clientes a alcançar seus objetivos de negócios por meio de tecnologias avançadas e um atendimento ao cliente excepcional.</p>
                    
                    <h2 class="card-title">Nossa Visão</h2>
                    <p class="card-text">Ser reconhecida como a principal fornecedora de soluções tecnológicas inovadoras, com foco em qualidade, inovação e satisfação do cliente.</p>
                    
                    <h2 class="card-title">Nossos Valores</h2>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-check-circle text-success"></i> Inovação</li>
                        <li><i class="fas fa-check-circle text-success"></i> Excelência</li>
                        <li><i class="fas fa-check-circle text-success"></i> Comprometimento</li>
                        <li><i class="fas fa-check-circle text-success"></i> Integridade</li>
                    </ul>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Nossa Equipe</h2>
                    <div class="d-flex flex-wrap justify-content-center">
                        <!-- Example team member -->
                        <div class="card m-2" style="width: 18rem;">
                            <img src="https://via.placeholder.com/150" class="card-img-top" alt="Membro da Equipe">
                            <div class="card-body text-center">
                                <h5 class="card-title">Pedro Arthur</h5>
                                <p class="card-text">CEO & Fundador</p>
                            </div>
                        </div>
                        <!-- Add more team members similarly -->
                    </div>
                </div>

                <div class="col-lg-6">
                    <h2 class="text-center mb-4">Entre em Contato</h2>
                    <div class="card shadow-lg border-0 rounded">
                        <div class="card-body p-4">
                            <form>
                                <div class="form-group">
                                    <label for="name">Nome</label>
                                    <input type="text" class="form-control" id="name" placeholder="Seu nome">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="Seu email">
                                </div>
                                <div class="form-group">
                                    <label for="message">Mensagem</label>
                                    <textarea class="form-control" id="message" rows="4" placeholder="Sua mensagem"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Enviar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop
