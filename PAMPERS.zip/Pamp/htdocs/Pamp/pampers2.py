class Pai(object):
   

    def __init__ (self, nome ,cargo):

        print (f'Meu nome é {nome}')


        self.trabalho = cargo()

def chamar (self):
        print ("Filho vem aqui")

def meu_trabalho (self):
                print(f"Minha profissão é {self.trabalho}")

meuPai = Pai('Fulano', 'Empresário')
meuPai.chamar()
meuPai.meu_trabalho()

trabalho = Pai